/*
 * custom_pins.ino
 * ───────────────
 * Example 1: explicit pin configuration
 *
 * Hardware
 * --------
 *  p1 – WS2812B NeoPixel: power pin 11, data pin 12
 *       (these are the XIAO RP2040 onboard NeoPixel pins)
 *  p2 – common-anode RGB LED: R=17, G=16, B=25
 *       (these are the XIAO RP2040 onboard RGB LED pins)
 *
 * Behaviour
 * ---------
 *  setup() : NeoPixel → red,  RGB LED → custom colour (50, 20, 80)
 *  loop()  : NeoPixel smooth rainbow at speed 4
 *            RGB LED  smooth rainbow at speed 6
 */

#include "npxlm.h"

pxl  p1;   // WS2812B NeoPixel  (uses PIO on RP2040)
pxlp p2;   // PWM common-anode RGB LED

void setup() {
  // ── NeoPixel ──────────────────────────────────────────────
  p1.pin(11, 12);      // power = 11, data = 12
  p1.setColor("red");  // show red at startup

  // ── RGB LED ───────────────────────────────────────────────
  p2.pin(17, 16, 25);      // r = 17, g = 16, b = 25
  p2.write(50, 20, 80);    // 50 % red, 20 % green, 80 % blue
}

void loop() {
  // Both calls are NON-BLOCKING.  They track their own timing
  // with millis() and only update the LED when the interval
  // for the selected speed has elapsed.  Call every loop().
  p1.rgb(4);   // NeoPixel: medium-slow rainbow
  p2.rgb(6);   // RGB LED:  medium-fast rainbow
}
