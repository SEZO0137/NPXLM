/*
 * default_pins.ino
 * ────────────────
 * Example 2: no pin() call — use built-in defaults
 *
 * This is the simplest possible usage of npxlm.
 * No pin configuration is needed because the defaults match
 * the XIAO RP2040 onboard NeoPixel and onboard RGB LED.
 *
 * Defaults
 * --------
 *  pxl  → power = 11, data = 12  (onboard NeoPixel)
 *  pxlp → r = 17, g = 16, b = 25 (onboard RGB LED)
 *
 * Behaviour
 * ---------
 *  setup() : NeoPixel → blue,  RGB LED → (30, 60, 90)
 *  loop()  : NeoPixel smooth rainbow at speed 3
 *            RGB LED  smooth rainbow at speed 5
 */

#include "npxlm.h"

pxl  p1;   // WS2812B NeoPixel  (uses PIO on RP2040)
pxlp p2;   // PWM common-anode RGB LED

void setup() {
  // No p1.pin() or p2.pin() call needed — the library
  // automatically uses the XIAO RP2040 onboard LED pins.

  p1.setColor("blue");   // NeoPixel: blue at startup
  p2.write(30, 60, 90);  // RGB LED: 30% red, 60% green, 90% blue
}

void loop() {
  p1.rgb(3);   // NeoPixel: slow smooth rainbow
  p2.rgb(5);   // RGB LED:  medium smooth rainbow
}
