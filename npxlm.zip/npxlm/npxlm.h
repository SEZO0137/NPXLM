/*
 * ============================================================
 *  npxlm.h  –  NeoPixel & PWM LED library
 *  Target  : Seeed XIAO RP2040 (also supports AVR and others)
 *  No external libraries required.
 * ============================================================
 *
 *  WHY PIO IS USED ON RP2040 (and not NOP bit-bang)
 *  ─────────────────────────────────────────────────
 *  The Cortex-M0+ on RP2040 runs code from flash via an XIP
 *  (Execute-In-Place) cache.  A cache miss can stall execution
 *  for 10-50+ ns unpredictably, which is enough to violate the
 *  WS2812B's ±150 ns timing tolerance and produce wrong colours
 *  or no signal at all.
 *
 *  The RP2040 PIO (Programmable I/O) co-processor runs a small
 *  dedicated program in its own SRAM with a hardware clock
 *  divider.  Each bit is timed to exactly one PIO clock cycle
 *  (~125 ns), with zero CPU involvement and zero cache effects.
 *  This is the same strategy used by Adafruit NeoPixel and
 *  FastLED when targeting the RP2040.
 *
 *  Classes
 *  -------
 *  pxl   – Single WS2812B NeoPixel LED
 *  pxlp  – PWM common-anode RGB LED
 *
 *  Quick-start
 *  -----------
 *  pxl p1;                  // defaults: power=11, data=12
 *  p1.pin(11, 12);          // optional – override pins
 *  p1.setColor("red");      // named colour
 *  p1.write(50, 0, 0);      // r g b  (0–100 scale)
 *  p1.rgb(5);               // smooth rainbow — call every loop()
 *
 *  pxlp p2;                 // defaults: r=17, g=16, b=25
 *  p2.pin(17, 16, 25);      // optional – override pins
 *  p2.write(100, 0, 0);     // full red
 *  p2.rgb(5);               // smooth rainbow — call every loop()
 */

#ifndef NPXLM_H
#define NPXLM_H

#include <Arduino.h>

// Pull in RP2040 PIO and clock support.
// These headers are part of the Pico SDK that ships with the
// arduino-pico core (Earle Philhower) — no extra installation.
#ifdef ARDUINO_ARCH_RP2040
  #include "hardware/pio.h"
  #include "hardware/clocks.h"
#endif

// ────────────────────────────────────────────────────────────────
//  pxl  –  WS2812B NeoPixel controller  (single LED)
// ────────────────────────────────────────────────────────────────
class pxl {
public:
    /**
     * Constructor – uses default pins until pin() is called.
     * Defaults: power = 11, data = 12  (XIAO RP2040 onboard NeoPixel)
     */
    pxl();

    /**
     * Set GPIO pins.
     *   powerPin – HIGH enables the NeoPixel's VCC rail.
     *   dataPin  – WS2812B 1-wire data line.
     * Optional: skip this call to use the defaults above.
     */
    void pin(uint8_t powerPin, uint8_t dataPin);

    /**
     * Show a named colour (case-insensitive).
     * Supported names: red  green  blue  white
     *                  yellow  purple  cyan  orange
     * Any unknown name turns the LED off.
     */
    void setColor(const char* name);

    /**
     * Write an arbitrary colour.
     * r, g, b : 0–100  (internally scaled to 0–255)
     * Values outside 0–100 are clamped automatically.
     */
    void write(uint8_t r, uint8_t g, uint8_t b);

    /**
     * Smooth continuous rainbow cycle.
     * NON-BLOCKING — call once every loop() iteration.
     * speed : 0 = frozen
     *         1 = very slow  (~60 s per full revolution)
     *        10 = very fast  (~0.5 s per full revolution)
     */
    void rgb(uint8_t speed);

private:
    uint8_t       _pwrPin;
    uint8_t       _dataPin;
    bool          _ready;
    uint16_t      _hue;
    unsigned long _lastMs;

#ifdef ARDUINO_ARCH_RP2040
    PIO  _pio;  // PIO block (pio0 or pio1)
    uint _sm;   // state machine index (0-3)
#endif

    void _ensureInit();
    void _sendColor(uint8_t r, uint8_t g, uint8_t b);

#ifndef ARDUINO_ARCH_RP2040
    // Bit-bang helper used only on non-RP2040 platforms
    void _sendByte(uint8_t b);
#endif
};

// ────────────────────────────────────────────────────────────────
//  pxlp  –  PWM RGB LED controller  (common-anode)
// ────────────────────────────────────────────────────────────────
class pxlp {
public:
    /**
     * Constructor – uses default pins until pin() is called.
     * Defaults: r = 17, g = 16, b = 25  (XIAO RP2040 onboard RGB LED)
     */
    pxlp();

    /**
     * Set PWM output pins for each colour channel.
     * Optional: skip this call to use the defaults above.
     */
    void pin(uint8_t rPin, uint8_t gPin, uint8_t bPin);

    /**
     * Write an arbitrary colour.
     * r, g, b : 0–100  (scaled to PWM, inverted for common-anode)
     * Values outside 0–100 are clamped automatically.
     */
    void write(uint8_t r, uint8_t g, uint8_t b);

    /**
     * Smooth continuous rainbow cycle.
     * NON-BLOCKING — call once every loop() iteration.
     * speed : 0–10 (same scale as pxl::rgb)
     */
    void rgb(uint8_t speed);

private:
    uint8_t       _rPin, _gPin, _bPin;
    bool          _ready;
    uint16_t      _hue;
    unsigned long _lastMs;

    void _ensureInit();
    void _writeRaw(uint8_t r, uint8_t g, uint8_t b);
};

#endif  // NPXLM_H
