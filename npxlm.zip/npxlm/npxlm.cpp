/*
 * ============================================================
 *  npxlm.cpp  –  NeoPixel & PWM LED library implementation
 *  Target  : Seeed XIAO RP2040 (also supports AVR and others)
 * ============================================================
 */

#include "npxlm.h"

// ════════════════════════════════════════════════════════════
//  Shared helpers (used by both pxl and pxlp)
// ════════════════════════════════════════════════════════════

/*
 * hsvToRgb  –  convert a hue angle to R, G, B (0-255 each)
 *
 * h  : hue in degrees, 0-359
 *       0° = red, 60° = yellow, 120° = green,
 *      180° = cyan, 240° = blue, 300° = magenta
 *
 * Saturation and value are both fixed at maximum (100 %).
 * The hue circle is divided into 6 × 60° sectors; within each
 * sector one channel rises from 0→255 while another falls.
 */
static void hsvToRgb(uint16_t h, uint8_t &r, uint8_t &g, uint8_t &b) {
    uint8_t sector  = h / 60;                          // which 60° sector (0-5)
    uint8_t frac    = (uint8_t)((h % 60) * 255 / 60);  // position within sector
    uint8_t falling = 255 - frac;                       // descending slope
    uint8_t rising  = frac;                             // ascending slope

    switch (sector) {
        case 0:  r = 255;    g = rising;  b = 0;       break; // red    → yellow
        case 1:  r = falling; g = 255;   b = 0;       break; // yellow → green
        case 2:  r = 0;      g = 255;    b = rising;  break; // green  → cyan
        case 3:  r = 0;      g = falling; b = 255;    break; // cyan   → blue
        case 4:  r = rising;  g = 0;     b = 255;    break; // blue   → magenta
        default: r = 255;    g = 0;      b = falling; break; // magenta→ red
    }
}

/*
 * strEqI  –  case-insensitive string comparison.
 * Returns true when a and b contain the same characters
 * regardless of upper/lower case.  Uses plain ASCII arithmetic
 * so it works without any locale or POSIX overhead.
 */
static bool strEqI(const char* a, const char* b) {
    while (*a && *b) {
        char ca = (*a >= 'A' && *a <= 'Z') ? (char)(*a + 32) : *a;
        char cb = (*b >= 'A' && *b <= 'Z') ? (char)(*b + 32) : *b;
        if (ca != cb) return false;
        ++a;
        ++b;
    }
    return (*a == '\0') && (*b == '\0');
}


// ════════════════════════════════════════════════════════════
//  RP2040 PIO WS2812B engine
// ════════════════════════════════════════════════════════════
#ifdef ARDUINO_ARCH_RP2040
/*
 *  HOW THE PIO PROGRAM WORKS
 *  ─────────────────────────
 *  The RP2040 has two PIO blocks (pio0, pio1), each with four
 *  independent state machines that run their own program loop.
 *  State machines have access to a hardware clock divider and
 *  GPIO "side-set" – the ability to drive a GPIO pin to a
 *  known level as a zero-cost side-effect of any instruction.
 *  This combination produces perfectly timed WS2812B pulses
 *  without touching the CPU at all.
 *
 *  PIO PROGRAM SOURCE (ws2812.pio, from Raspberry Pi Pico SDK):
 *  ─────────────────────────────────────────────────────────────
 *    .program ws2812
 *    .side_set 1            ; 1 side-set bit drives the data GPIO
 *
 *    .wrap_target           ; loop start
 *    bitloop:
 *      out x, 1   side 0 [T3-1]  ; shift 1 bit into X; data LOW T3 cycles
 *      jmp !x, 3  side 1 [T1-1]  ; if bit=0 jump to do_zero; data HIGH T1 cycles
 *    do_one:
 *      jmp bitloop side 1 [T2-1] ; bit=1: stay high T2 more cycles, then loop
 *    do_zero:
 *      nop        side 0 [T2-1]  ; bit=0: drive low T2 cycles, then loop
 *    .wrap                  ; loop end (wraps back to .wrap_target)
 *
 *  TIMING  (T1=2, T2=5, T3=3; clock divider = 15.625 → 8 MHz PIO clock)
 *  ───────────────────────────────────────────────────────────────────────
 *  Each PIO clock cycle = 125 MHz / 15.625 = 8 MHz → 125 ns
 *
 *  Bit-1 waveform:
 *    HIGH = (T1+T2) × 125 ns = 7 × 125 = 875 ns  [spec 650-950 ns] ✓
 *    LOW  =  T3     × 125 ns = 3 × 125 = 375 ns  [spec 300-600 ns] ✓
 *
 *  Bit-0 waveform:
 *    HIGH =  T1     × 125 ns = 2 × 125 = 250 ns  [spec 250-550 ns] ✓
 *    LOW  = (T2+T3) × 125 ns = 8 × 125 = 1000 ns [spec 700-1000 ns] ✓
 *
 *  Reset pulse: CPU drives data LOW for > 50 µs after TX finishes.
 *
 *  PRE-ASSEMBLED BINARY
 *  ─────────────────────
 *  The program is stored as raw 16-bit PIO opcodes so that
 *  no external pioasm tool is required at compile time.
 *  These values match the output of pioasm in the official
 *  Pico SDK examples (pico-examples/pio/ws2812/generated/).
 */

static const uint16_t _ws2812_instrs[] = {
    0x6221, // 0: out x, 1       side 0 [2]  (T3-1 = 2 delay cycles)
    0x1123, // 1: jmp !x, 3      side 1 [1]  (T1-1 = 1 delay cycle)
    0x1400, // 2: jmp 0          side 1 [4]  (T2-1 = 4 delay cycles) ← bit=1 path
    0xA442, // 3: nop            side 0 [4]  (T2-1 = 4 delay cycles) ← bit=0 path
};

// pio_program_t is a plain struct { const uint16_t*, uint8_t, int8_t }
// origin = -1 means "place anywhere in PIO instruction memory"
static const pio_program_t _ws2812_program = {
    _ws2812_instrs, // .instructions
    4,              // .length  (4 instructions)
    -1              // .origin  (-1 = no fixed position required)
};

// ── Static PIO program management ────────────────────────────
// The PIO instruction memory is shared across all state machines
// in a block.  We load the 4-instruction program only once per
// PIO block and reuse the offset for every pxl instance.
static bool  _pioLoaded = false;  // has the program been loaded?
static uint  _pioOffset;          // instruction-memory offset (0-28)

// ── Internal helper ──────────────────────────────────────────
// Claim and configure a fresh state machine for the given data pin.
static void _pioSetup(PIO pio, uint sm, uint offset, uint8_t dataPin) {
    // Build a default config, then override only what we need.
    pio_sm_config cfg = pio_get_default_sm_config();

    // Set the loop boundaries so the state machine wraps after
    // instruction 3 (nop) back to instruction 0 (out x,1).
    sm_config_set_wrap(&cfg, offset + 0, offset + 3);

    // Declare 1 side-set bit (non-optional, not pindirs mode).
    sm_config_set_sideset(&cfg, 1, false, false);

    // Route the side-set output to our data GPIO.
    sm_config_set_sideset_pins(&cfg, dataPin);

    // OSR: shift left (MSB first), auto-pull after 24 bits consumed.
    // Auto-pull means the SM refills the OSR from the TX FIFO by
    // itself; we just push 32-bit words into the FIFO.
    sm_config_set_out_shift(&cfg, false, true, 24);

    // Join both TX FIFOs together for an 8-entry depth.
    // Not strictly needed for 1 LED but provides a small buffer.
    sm_config_set_fifo_join(&cfg, PIO_FIFO_JOIN_TX);

    // Set the PIO clock divider so that 1 PIO cycle = 125 ns.
    // 10 PIO cycles per WS2812B bit × 800 000 bits/s = 8 MHz PIO clock.
    // clock_get_hz(clk_sys) normally returns 125 000 000 on RP2040.
    float div = (float)clock_get_hz(clk_sys) / (10.0f * 800000.0f);
    sm_config_set_clkdiv(&cfg, div);

    // Hand ownership of the data GPIO to the PIO block and
    // configure it as an output (direction = true).
    pio_gpio_init(pio, dataPin);
    pio_sm_set_consecutive_pindirs(pio, sm, dataPin, 1, true);

    // Initialise and start the state machine.
    pio_sm_init(pio, sm, offset, &cfg);
    pio_sm_set_enabled(pio, sm, true);
}

#endif  // ARDUINO_ARCH_RP2040


// ════════════════════════════════════════════════════════════
//  pxl  –  WS2812B NeoPixel
// ════════════════════════════════════════════════════════════

// ── Constructor ──────────────────────────────────────────────
pxl::pxl()
    : _pwrPin(11), _dataPin(12), _ready(false), _hue(0), _lastMs(0)
{
    // Pin setup is deferred to first use so that global objects
    // declared before setup() work without needing explicit init.
}

// ── pin() ────────────────────────────────────────────────────
void pxl::pin(uint8_t powerPin, uint8_t dataPin) {
    _pwrPin  = powerPin;
    _dataPin = dataPin;
    _ready   = false;   // force re-initialisation with new pins
    _ensureInit();
}

// ── _ensureInit() ────────────────────────────────────────────
// Called automatically before every colour transmission.
// Configures GPIO (and PIO on RP2040) exactly once.
void pxl::_ensureInit() {
    if (_ready) return;

    // Power pin: enables VCC to the onboard NeoPixel on XIAO RP2040.
    // On other boards where the LED is always powered, this is a
    // normal GPIO that can be left disconnected – it does no harm.
    pinMode(_pwrPin, OUTPUT);
    digitalWrite(_pwrPin, HIGH);
    delay(1);  // let the WS2812B internal LDO stabilise

#ifdef ARDUINO_ARCH_RP2040
    // Load the PIO program into pio0 if not already done.
    // Multiple pxl objects share the same program image but each
    // gets its own state machine and its own data pin.
    if (!_pioLoaded) {
        _pioOffset = pio_add_program(pio0, &_ws2812_program);
        _pioLoaded = true;
    }
    _pio = pio0;
    _sm  = pio_claim_unused_sm(_pio, true);  // true = panic if none free
    _pioSetup(_pio, _sm, _pioOffset, _dataPin);

#else
    // On non-RP2040 boards, plain GPIO bit-bang is used.
    // The data pin idles LOW between transmissions.
    pinMode(_dataPin, OUTPUT);
    digitalWrite(_dataPin, LOW);
#endif

    _ready = true;

    // Send black immediately to prevent the power-on random colour
    // that some WS2812B chips display when they first receive power.
    _sendColor(0, 0, 0);
}

// ── _sendColor() ─────────────────────────────────────────────
// Transmit one 24-bit WS2812B frame then hold data LOW
// long enough to latch the colour into the LED.
void pxl::_sendColor(uint8_t r, uint8_t g, uint8_t b) {
    _ensureInit();

#ifdef ARDUINO_ARCH_RP2040
    /*
     *  Pack the three colour bytes into a 32-bit word, left-aligned.
     *  WS2812B byte order is GRB (Green first, then Red, then Blue).
     *  The OSR shifts left (MSB first) and auto-pulls after 24 bits,
     *  so bits 31..8 of the word carry the colour data; bits 7..0
     *  are never shifted out and can be left as zero.
     *
     *    Bit 31 ──────────────────── Bit 8   Bits 7..0
     *    [  G[7..0]  ][  R[7..0]  ][  B[7..0]  ][  0  ]
     */
    uint32_t grb = ((uint32_t)g << 24)
                 | ((uint32_t)r << 16)
                 | ((uint32_t)b <<  8);

    // Push into TX FIFO.  _blocking_ waits if the FIFO is full
    // (never an issue for a single LED, but correct practice).
    pio_sm_put_blocking(_pio, _sm, grb);

    /*
     *  Wait for the transmission to finish before asserting the
     *  reset pulse.  Timeline after pio_sm_put_blocking returns:
     *
     *    1. Word moved from FIFO → OSR instantly
     *    2. 24 bits clocked out at 800 kHz  ≈ 30 µs
     *    3. OSR empty → state machine stalls at 'out x,1 side 0'
     *       (data line held LOW by side-set) – this is the reset.
     *
     *  We wait until the TX FIFO empties (word moved to OSR),
     *  then add 50 µs for the remaining bit-clock time plus the
     *  mandatory > 50 µs reset interval.  100 µs covers both.
     */
    while (!pio_sm_is_tx_fifo_empty(_pio, _sm)) { /* spin ~0 µs */ }
    delayMicroseconds(100);  // ~30 µs TX tail + ≥50 µs reset

#else
    // ── Non-RP2040: interrupt-disabled bit-bang ───────────────
    // Disable interrupts for the duration to prevent ISR jitter.
    noInterrupts();
    _sendByte(g);   // WS2812B byte order: Green first
    _sendByte(r);   //                     Red   second
    _sendByte(b);   //                     Blue  last
    interrupts();
    delayMicroseconds(60);  // reset / latch pulse (>50 µs)
#endif
}


// ── _sendByte()  (non-RP2040 only) ───────────────────────────
#ifndef ARDUINO_ARCH_RP2040
/*
 * Bit-bang one byte MSB-first onto _dataPin.
 *
 * Caller MUST call noInterrupts() before this function and
 * interrupts() after the complete 3-byte frame is sent.
 *
 * This fallback targets 16 MHz AVR (e.g. Arduino Uno/Nano).
 * Timing is achieved via direct port register writes and
 * inline ASM NOPs.  It will also compile for other platforms
 * but timing accuracy is not guaranteed.
 */
void pxl::_sendByte(uint8_t data) {
#if defined(__AVR__)
    /*
     *  AVR: Direct PORT register access.
     *  digitalWrite() takes ~3.5 µs — far too slow for WS2812B.
     *  SBI/CBI on the port register takes exactly 2 cycles (125 ns
     *  at 16 MHz).  Loop overhead ≈ 5–6 cycles = 312–375 ns.
     *
     *  Measured timing at 16 MHz (1 cycle = 62.5 ns):
     *    T1H: (2+11) × 62.5 = 812 ns  [spec 650-950] ✓
     *    T1L: (2+ 0+loop) ≈  500 ns  [spec 300-600] ✓
     *    T0H: (2+ 4) × 62.5 = 375 ns  [spec 250-550] ✓
     *    T0L: (2+ 5+loop) ≈  812 ns  [spec 700-1000] ✓
     */
    uint8_t  bitMask = digitalPinToBitMask(_dataPin);
    volatile uint8_t* portReg = portOutputRegister(digitalPinToPort(_dataPin));

    for (uint8_t i = 0; i < 8; i++) {
        if (data & 0x80) {
            // Bit = 1 ─────────────────────────────────────────
            *portReg |= bitMask;                            // HIGH
            __asm__ volatile(
                "nop\nnop\nnop\nnop\nnop\n"
                "nop\nnop\nnop\nnop\nnop\nnop\n"   // 11 NOPs → T1H
            );
            *portReg &= ~bitMask;                           // LOW (T1L from loop overhead)
        } else {
            // Bit = 0 ─────────────────────────────────────────
            *portReg |= bitMask;                            // HIGH
            __asm__ volatile("nop\nnop\nnop\nnop");         // 4 NOPs → T0H
            *portReg &= ~bitMask;                           // LOW
            __asm__ volatile("nop\nnop\nnop\nnop\nnop");    // 5 NOPs → T0L
        }
        data <<= 1;
    }

#else
    /*
     *  Generic fallback.  Uses digitalWrite() + delayMicroseconds().
     *  Timing is approximate and may not be reliable for all
     *  WS2812B variants.  For accurate output on any new platform,
     *  add a platform-specific #elif branch above (or use PIO/SPI).
     */
    for (uint8_t i = 0; i < 8; i++) {
        if (data & 0x80) {
            digitalWrite(_dataPin, HIGH);
            delayMicroseconds(1);    // ≈ 800 ns HIGH
            digitalWrite(_dataPin, LOW);
            // LOW period comes from function overhead + next iteration
        } else {
            digitalWrite(_dataPin, HIGH);
            // HIGH period comes from function overhead alone
            digitalWrite(_dataPin, LOW);
            delayMicroseconds(1);    // ≈ 850 ns LOW
        }
        data <<= 1;
    }
#endif
}
#endif  // !ARDUINO_ARCH_RP2040


// ── setColor() ───────────────────────────────────────────────
void pxl::setColor(const char* name) {
    // Named colour lookup table (stored in flash)
    static const struct {
        const char* label;
        uint8_t r, g, b;
    } tbl[] = {
        { "red",    255,   0,   0 },
        { "green",    0, 255,   0 },
        { "blue",     0,   0, 255 },
        { "white",  255, 255, 255 },
        { "yellow", 255, 255,   0 },
        { "purple", 128,   0, 128 },
        { "cyan",     0, 255, 255 },
        { "orange", 255, 165,   0 },
    };

    for (uint8_t i = 0; i < sizeof(tbl) / sizeof(tbl[0]); i++) {
        if (strEqI(name, tbl[i].label)) {
            _sendColor(tbl[i].r, tbl[i].g, tbl[i].b);
            return;
        }
    }
    _sendColor(0, 0, 0);   // unknown name → LED off
}

// ── write() ──────────────────────────────────────────────────
void pxl::write(uint8_t r, uint8_t g, uint8_t b) {
    // Clamp 0-100, then scale to 0-255.
    // uint16_t intermediate prevents overflow before the multiply.
    r = constrain(r, 0, 100);
    g = constrain(g, 0, 100);
    b = constrain(b, 0, 100);

    _sendColor(
        (uint8_t)((uint16_t)r * 255 / 100),
        (uint8_t)((uint16_t)g * 255 / 100),
        (uint8_t)((uint16_t)b * 255 / 100)
    );
}

// ── rgb() ────────────────────────────────────────────────────
void pxl::rgb(uint8_t speed) {
    if (speed == 0) return;
    speed = constrain(speed, 1, 10);

    /*
     *  Map speed 1-10 to an update interval and a hue step per update.
     *
     *  speed  interval  step  approx rev time
     *    1      80 ms    1°      ~29 s
     *    5      40 ms    3°       ~5 s
     *   10       8 ms    5°       ~0.6 s
     *
     *  Using both parameters gives a wide, perceptibly smooth range
     *  without hitting the ~100 µs _sendColor cost too frequently.
     */
    uint16_t interval = (uint16_t)map(speed, 1, 10, 80, 8);   // ms between updates
    uint8_t  step     = (uint8_t) map(speed, 1, 10, 1,  5);   // degrees per update

    unsigned long now = millis();
    if (now - _lastMs < interval) return;   // not yet time to update
    _lastMs = now;

    _hue = (_hue + step) % 360;

    uint8_t r, g, b;
    hsvToRgb(_hue, r, g, b);
    _sendColor(r, g, b);
}


// ════════════════════════════════════════════════════════════
//  pxlp  –  PWM common-anode RGB LED
//
//  Common-anode wiring
//  ───────────────────
//  The shared anode (+) is connected to VCC.  Each colour
//  cathode is driven through a current-limiting resistor by
//  a PWM-capable GPIO.
//
//  Because the anode is always at VCC, output polarity is
//  inverted versus what you might expect:
//    analogWrite(pin,   0) → pin LOW  → maximum current → FULL brightness
//    analogWrite(pin, 255) → pin HIGH → no current       → OFF
//
//  So for a user brightness B (0-255):
//    analogWrite(pin, 255 - B)
// ════════════════════════════════════════════════════════════

// ── Constructor ──────────────────────────────────────────────
pxlp::pxlp()
    : _rPin(17), _gPin(16), _bPin(25), _ready(false), _hue(0), _lastMs(0)
{
    // Default pins match the XIAO RP2040 onboard user RGB LED.
}

// ── pin() ────────────────────────────────────────────────────
void pxlp::pin(uint8_t rPin, uint8_t gPin, uint8_t bPin) {
    _rPin  = rPin;
    _gPin  = gPin;
    _bPin  = bPin;
    _ready = false;
    _ensureInit();
}

// ── _ensureInit() ────────────────────────────────────────────
void pxlp::_ensureInit() {
    if (_ready) return;

    pinMode(_rPin, OUTPUT);
    pinMode(_gPin, OUTPUT);
    pinMode(_bPin, OUTPUT);

    // Common anode: write 255 (= HIGH = 0 current) to turn all channels off.
    analogWrite(_rPin, 255);
    analogWrite(_gPin, 255);
    analogWrite(_bPin, 255);

    _ready = true;
}

// ── _writeRaw() ──────────────────────────────────────────────
// Internal write; r, g, b already in 0-255 range.
// Inverts each value to compensate for common-anode polarity.
void pxlp::_writeRaw(uint8_t r, uint8_t g, uint8_t b) {
    _ensureInit();
    analogWrite(_rPin, 255 - r);   // 0 → full on, 255 → off
    analogWrite(_gPin, 255 - g);
    analogWrite(_bPin, 255 - b);
}

// ── write() ──────────────────────────────────────────────────
void pxlp::write(uint8_t r, uint8_t g, uint8_t b) {
    r = constrain(r, 0, 100);
    g = constrain(g, 0, 100);
    b = constrain(b, 0, 100);

    _writeRaw(
        (uint8_t)((uint16_t)r * 255 / 100),
        (uint8_t)((uint16_t)g * 255 / 100),
        (uint8_t)((uint16_t)b * 255 / 100)
    );
}

// ── rgb() ────────────────────────────────────────────────────
void pxlp::rgb(uint8_t speed) {
    if (speed == 0) return;
    speed = constrain(speed, 1, 10);

    uint16_t interval = (uint16_t)map(speed, 1, 10, 80, 8);
    uint8_t  step     = (uint8_t) map(speed, 1, 10, 1,  5);

    unsigned long now = millis();
    if (now - _lastMs < interval) return;
    _lastMs = now;

    _hue = (_hue + step) % 360;

    uint8_t r, g, b;
    hsvToRgb(_hue, r, g, b);
    _writeRaw(r, g, b);
}
